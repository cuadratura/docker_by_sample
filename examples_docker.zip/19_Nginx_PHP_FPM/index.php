<?php 

phpinfo(); 

?>